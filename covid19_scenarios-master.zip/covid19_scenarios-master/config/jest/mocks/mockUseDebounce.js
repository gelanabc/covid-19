export function useDebouncedCallback(f) {
  return [f]
}
