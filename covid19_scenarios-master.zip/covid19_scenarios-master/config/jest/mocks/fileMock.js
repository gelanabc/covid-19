module.exports = __filename
