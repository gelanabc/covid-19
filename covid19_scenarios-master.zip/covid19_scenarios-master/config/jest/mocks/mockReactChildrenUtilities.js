module.exports = {
  onlyText: (text) => text,
}
