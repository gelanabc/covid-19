# covid19_scenarios/3rdparty

This directory contains 3rdparty packages that we want to include into our 
repository, for any reason.
